import React from 'react'

const Edit = () => {
  return (
    <div>Edit</div>
  )
}

export default Edit;